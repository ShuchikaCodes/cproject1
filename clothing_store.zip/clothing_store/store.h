#ifndef STORE_H
#define STORE_H

// Struct to represent an item in the store
typedef struct {
    char name[50];
    float price;
} Item;

// Function to initialize the inventory
void initializeInventory(Item inventory[], int size);

// Function to display the available items
void displayInventory(Item inventory[], int size);

// Function to calculate the total bill
float calculateBill(Item inventory[], int size, int items[], int quantities[], int numItems);

#endif
